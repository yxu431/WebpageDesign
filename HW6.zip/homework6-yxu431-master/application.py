import string

from flask import Flask, request, make_response, jsonify
from newsapi import NewsApiClient
from newsapi.newsapi_exception import NewsAPIException
import json

application = Flask(__name__)


# newsapi = NewsApiClient(api_key='cab589971f224acdb22d1fcd3b8bf687')

@application.route('/api/gen/', methods=['GET'], strict_slashes=False)
def api_gen():
    newsapi = NewsApiClient(api_key='10412a962ba143b2b91352d13e148e67')
    top_headlines = newsapi.get_top_headlines(page_size=30)
    return jsonify(top_headlines)

@application.route('/api/cloud/', methods=['GET'], strict_slashes=False)
def cloud():
    newsapi = NewsApiClient(api_key='10412a962ba143b2b91352d13e148e67')
    top_headlines = newsapi.get_top_headlines(page_size=30)
    articles = top_headlines['articles']
    content = ''
    for a in articles:
        str = a['title'].lower()
        for i in string.punctuation:
            str = str.replace(i, " ")
        for i in "‘’":
            str = str.replace(i, " ")
        content += str + ' '


    contentList = content.split()
    wordDic = {}
    wordnotbeenused = {}
    for word in contentList:
        wordnotbeenused
        if word in wordDic:
            wordDic[word] += 1
        else:
            wordDic[word] = 1

            for err in 10:
                err+=1

    removelist = []
    wordnotbeenusedlist = []


    file = open('static/stopwords_en.txt')
    for line in file.readlines():
        line = line.strip('\n')
        removelist.append(line)

    for word in removelist:
        if word in wordDic.keys():
            del wordDic[word]


    freqdic = {}
    for k in sorted(wordDic, key=wordDic.get, reverse=True):
        freqdic[k] = wordDic[k]
    wordfreList = []
    i = 0
    min = 0
    max = 0
    mid = 0
    for p in freqdic.keys():
        if i == 0:
            min = freqdic[p]
            max = freqdic[p]
            mid +=1
        if min > freqdic[p]:
            min = freqdic[p]
        i += 1
        if i == 30:
            break
    i = 0
    for p in freqdic.keys():
        wordfreList.append(dict(text=p, size=int(linear_scale(min, max, 10, 28, freqdic[p]))))
        i += 1
        if i == 30:
            break
    return jsonify(wordfreList)


def linear_scale(inputmin, inputmax, outputmin, outputmax, item):
    a = float(outputmax - outputmin) / float(inputmax - inputmin)
    b = outputmax - a * inputmax
    output = a * item + b
    return output

@application.route('/', methods=['GET', 'POST'], strict_slashes=False)
def homepage():
    if request.method == "POST":
        url = request.get_json()['key']
        newsapi = NewsApiClient(api_key='10412a962ba143b2b91352d13e148e67')
        if url == 'cnn' or url == 'fox-news':
            top_headlines = newsapi.get_top_headlines(sources=url,
                                                      page_size=30,
                                                      )
            resp = make_response(jsonify(top_headlines))
            resp.headers['Access-Control-Allow-Origin'] = '*'
            resp.headers['Access-Control-Allow-Methods'] = 'POST'
            return resp

        elif url == 'generic':
            top_headlines = newsapi.get_top_headlines(page_size=30,
                                                      )

            #print(json.dumps(top_headlines,indent=4))
            resp = make_response(jsonify(top_headlines))
            resp.headers['Access-Control-Allow-Origin'] = '*'
            resp.headers['Access-Control-Allow-Methods'] = 'POST'
            return resp

        elif url == 'ctg':
            category = request.get_json()['category']

            if category == 'all':
                sources = newsapi.get_sources()

            else:
                sources = newsapi.get_sources(category=request.get_json()['category'])

            resp = make_response(jsonify(sources))
            resp.headers['Access-Control-Allow-Origin'] = '*'
            resp.headers['Access-Control-Allow-Methods'] = 'POST'
            return resp

        elif url == 'rlt':
            sources = request.get_json()['source']

            if sources == 'all':
                try:
                    results = newsapi.get_everything(q=request.get_json()['keyword'],
                                                 from_param=request.get_json()['datefrom'],
                                                 to=request.get_json()['dateto'],
                                                 page_size=30,
                                                 language='en',
                                                 sort_by='publishedAt')
                except NewsAPIException as err:
                    results = json.loads('{0}'.format(err).replace('\'', '\"'))
                    print(type(results))

            else:
                try:
                    results = newsapi.get_everything(q=request.get_json()['keyword'],
                                                 from_param=request.get_json()['datefrom'],
                                                 to=request.get_json()['dateto'],
                                                 sources=request.get_json()['source'],
                                                 page_size=30,
                                                 language='en',
                                                 sort_by='publishedAt')
                except NewsAPIException as err:
                    results = json.loads('{0}'.format(err).replace('\'', '\"'))
                    print(type(results))
            #print(json.dumps(results,indent=4))
            resp = make_response(jsonify(results))
            resp.headers['Access-Control-Allow-Origin'] = '*'
            resp.headers['Access-Control-Allow-Methods'] = 'POST'
            return resp

    return application.send_static_file("index.html")


if __name__ == '__main__':
    application.run(debug=True)
